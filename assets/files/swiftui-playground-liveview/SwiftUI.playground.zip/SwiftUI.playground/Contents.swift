import PlaygroundSupport

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hello!")
            Button(action: {
                print("Clicked")
            }, label: { Text("Click Me!") })
        }
    }
}


PlaygroundPage.current.setLiveView(ContentView())
